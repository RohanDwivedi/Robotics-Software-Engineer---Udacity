#!/bin/sh
xterm -hold -e  " roslaunch turtlebot_gazebo turtlebot_world.launch world_file:=$(find / -name map.world) " &

sleep 5

xterm  -hold -e  " roslaunch turtlebot_gazebo amcl_demo.launch map_file:=$(find / -name my_map.yaml) " &

sleep 3

xterm -hold -e  " roslaunch turtlebot_rviz_launchers view_navigation.launch "
